<?php
$conectare=mysqli_connect("localhost","root", "AM22te3})7Qn_V$:", "clothesforall" );
if(!$conectare){
     die("Error connecting");
}

?>